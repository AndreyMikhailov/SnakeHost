﻿using System.Drawing;

namespace SnakeHost
{
    public class PlayerState
    {
        public string Name { get; set; }
        public Point[] Snake { get; set; }
    }
}