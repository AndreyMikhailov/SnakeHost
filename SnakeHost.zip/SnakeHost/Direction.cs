﻿namespace SnakeHost
{
    public enum Direction
    {
        Left,
        Top,
        Right,
        Bottom
    }
}